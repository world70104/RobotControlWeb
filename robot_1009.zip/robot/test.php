<?php
$con = new mysqli("127.0.0.1", "root", "", "robotdb");
$sql = "SELECT * FROM admin";
$result = $con->query($sql);
$row = $result->fetch_assoc();
$msg = $row["password"];
$con->close();
echo "$msg <br/>";
echo "Hello From Sites Folder!";
?>