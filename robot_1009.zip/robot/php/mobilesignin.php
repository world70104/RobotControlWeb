<?php
/////////////////////////////////////////////////////////////////////////
//
//                          cookie.php 
//
//    get & set cookie
//
//
//  Date: 2018/09/25
//  Version: 1.0
//
//  Make by M.H team
//
//////////////////////////////////////////////////////////////////////////
    include 'robotdb.php';

    // Check connection
    if ($GLOBALS['conn']->connect_error) {
        // database connect failure
        echo "DB eror";
    } 
    else {
        // mobile signin
        if ( isset( $_GET['account'] ) ) {
            $account = $_GET['account'];
            $password = $_GET['pwd'];
            $platform = $_GET['platform'];
            $sql = "SELECT account, password FROM owner";   
            $result = $GLOBALS['conn']->query($sql);
            $check = false;
            // read the data
            if ($result->num_rows > 0) {
                // output data of each row
                while( $row = $result->fetch_assoc() )  {
                    if( 
                        ( $row["account"] == $account ) &&
                        ( $row["password"] == $password )
                     ) {
                        $check = true;
                        break;
                    }
                }
            }    
            if ( $check == false ) {
                $data = array( 'data'=>array('account'=>$account), 'status'=>false);
                echo json_encode($data);
            }
            else {
                $data = array( 'data'=>array('account'=>$account), 'status'=>true);
                echo json_encode($data);
            }
        }
        // db close
        $GLOBALS['conn']->close();   
    }
?>
