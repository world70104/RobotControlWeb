<?php
/////////////////////////////////////////////////////////////////////////
//
//                          cookie.php 
//
//    get & set cookie
//
//
//  Date: 2018/09/25
//  Version: 1.0
//
//  Make by M.H team
//
//////////////////////////////////////////////////////////////////////////
    include 'robotdb.php';

    // Check connection
    if ($GLOBALS['conn']->connect_error) {
        // database connect failure
        echo "error";
    } 
    else {
        // get
        if ( isset( $_REQUEST['get_user_rememberMeCheck'] ) ) {
            $sql = "SELECT 
                user_rememberMeCheck
                FROM cookie";
            $result = $GLOBALS['conn']->query($sql);
            $row = $result->fetch_assoc();
            echo ( $row['user_rememberMeCheck'] );
        }
        else if ( isset( $_REQUEST['get_user'] ) ) {
            $sql = "SELECT 
                user_account,  
                user_password
                FROM cookie";
            $result = $GLOBALS['conn']->query($sql);
            $row = $result->fetch_assoc();
            $data = array( $row['user_account'], $row['user_password'] );
            echo json_encode( array_values($data) );
        }
        else if ( isset( $_REQUEST['get_admin_rememberMeCheck'] ) ) {
            $sql = "SELECT 
                admin_rememberMeCheck
                FROM cookie";
            $result = $GLOBALS['conn']->query($sql);
            $row = $result->fetch_assoc();
            echo ( $row['admin_rememberMeCheck'] );
        }
        else if ( isset( $_REQUEST['get_admin'] ) ) {
            $sql = "SELECT 
                admin_account,  
                admin_password
                FROM cookie";
            $result = $GLOBALS['conn']->query($sql);
            $row = $result->fetch_assoc();
            $data = array( $row['admin_account'], $row['admin_password'] );
            echo json_encode( array_values($data) );
        }

        // set
        else if ( isset( $_REQUEST['set_user_rememberMeCheck'] ) ) {
            $sql = "SELECT id FROM cookie";
            $result = $GLOBALS['conn']->query($sql);
            $row = $result->fetch_assoc();
            $id = $row['id'];
            // get value
            $user_rememberMeCheck = $_REQUEST['user_rememberMeCheck'];
            $sql = "UPDATE cookie SET user_rememberMeCheck = '$user_rememberMeCheck'
                WHERE id = '$id'";
            $conn->query($sql);
        }
        else if ( isset( $_REQUEST['set_user'] ) ) {
            $sql = "SELECT id FROM cookie";
            $result = $GLOBALS['conn']->query($sql);
            $row = $result->fetch_assoc();
            $id = $row['id'];
            // get value
            $user_account = $_REQUEST['user_account'];
            $user_password = $_REQUEST['user_password'];
            $sql = "UPDATE cookie SET user_account = '$user_account', user_password = '$user_password'
                WHERE id = '$id'";
            $conn->query($sql);
        }
        else if ( isset( $_REQUEST['set_admin_rememberMeCheck'] ) ) {
            $sql = "SELECT id FROM cookie";
            $result = $GLOBALS['conn']->query($sql);
            $row = $result->fetch_assoc();
            $id = $row['id'];
            // get value
            $admin_rememberMeCheck = $_REQUEST['admin_rememberMeCheck'];
            $sql = "UPDATE cookie SET admin_rememberMeCheck = '$admin_rememberMeCheck'
                WHERE id = '$id'";
            $conn->query($sql);
        }
        else if ( isset( $_REQUEST['set_admin'] ) ) {
            $sql = "SELECT id FROM cookie";
            $result = $GLOBALS['conn']->query($sql);
            $row = $result->fetch_assoc();
            $id = $row['id'];
            // get value
            $admin_account = $_REQUEST['admin_account'];
            $admin_password = $_REQUEST['admin_password'];
            $sql = "UPDATE cookie SET admin_account = '$admin_account', admin_password = '$admin_password'
                WHERE id = '$id'";
            $conn->query($sql);
            
            echo $_REQUEST['admin_password'];
        }
        // db close
        $GLOBALS['conn']->close();   
    }
?>
