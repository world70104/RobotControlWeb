<?php
/////////////////////////////////////////////////////////////////////////
//
//                          email.php 
//
//    send email
//
//
//  Date: 2018/09/25
//  Version: 1.0
//
//  Make by M.H team
//
//////////////////////////////////////////////////////////////////////////

    // db open
    // Check connection
    if ( isset( $_REQUEST['receiver'] ) ) {

        $to = $_REQUEST['receiver'];
        $subject = "Verify code";
        $msg = $_REQUEST['verifycode'];

        // send email
        mail( $to, $subject, $msg );    
    }

?>
