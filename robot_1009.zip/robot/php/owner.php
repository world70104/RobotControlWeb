<?php
/////////////////////////////////////////////////////////////////////////
//
//                          owner.php 
//
//    owner login
//
//  return: 
//     if login
//          0 - no database( database connect failure )    
//          1 - successful in owner    
//          3 - search failure
//          4 - no robot
//          5 - offline
//          6 - occupy
//          7 - private
//          8 - account using    
//          9 - temp password fail    

//         0n/offline, ""/robot name, normal/private 
//  Date: 2018/09/25
//  Version: 1.0
//
//  Make by M.H team
//
//////////////////////////////////////////////////////////////////////////
    include 'robotdb.php';

    // db open
    // Check connection
    if ($GLOBALS['conn']->connect_error) {
        // database connect failure
        echo "0";
    } 
    else {
        // owner login 
        if ( isset( $_GET['login'] ) ) {
            $account = $_GET['account'];
            $password = $_GET['password'];
            // owner check
                    // status check for visitor
            $sql = "SELECT id, account, password, lastlogintime, blockvisitor, accesslink, 
                temppassword, status, onoffline, useaccount, robotname FROM owner";   
            $result = $GLOBALS['conn']->query($sql);
            $isStatus = false;
            // read the data
            if ($result->num_rows > 0) {
                while( $row = $result->fetch_assoc() )  {
                    // account and password same ?
                    if(
                        ( $row['account'] == $account ) &&
                        ( $row['password'] == $password ) ) {

                        $isStatus = true;

                        // account using check ?
                        if( $row["useaccount"] == $account ) {
                            echo "8";
                        }
                        // robot occupy
                        else if ( $row["useaccount"] != "" ) {
                            $sqlBlockvisitor = $row["blockvisitor"];
                            $sqlBlockvisitor += 1;
                            // update blockvisitor + 1 
                            $sql = "UPDATE owner SET 
                                blockvisitor = '$sqlBlockvisitor'
                                WHERE account = '$account'";
                            $conn->query($sql);
                            echo "6";
                        }     
                        // robot oline status
                        else if ( $row["onoffline"] == 'offline' ) {
                            echo "5";
                        }     
                        else  {
                            // SUCCESSFUL
                            echo "1";
                            // set last login time in owner
                            $date = date("Y-m-d h:i");    
                            $account = $_GET['account'];
                            $sql = "UPDATE owner SET lastlogintime = '$date', useaccount = '$account' 
                                WHERE account = '$account'";
                            $GLOBALS['conn']->query($sql);
                        }     

                        break;
                    }
                }
            }
            if ( $isStatus === false )
                echo "3";
        }
        $GLOBALS['conn']->close();   
    }
?>