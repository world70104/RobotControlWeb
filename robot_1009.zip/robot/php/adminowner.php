<?php
/////////////////////////////////////////////////////////////////////////
//
//                          adminowner.php 
//
//    visitor data for admin
//          if owner data read
//  return: 0 - no database( database connect failure )    
//          1 - now row    
//          other - json array    
//          if insert  new owner data
//          0 - no database( database connect failure )    
//          1 - add failure    
//          2 - add successful    
//          if delete  one owner data
//          0 - no database( database connect failure )    
//          1 - delete failure    
//          2 - delete successful    
//          if update  owner data
//          0 - no database( database connect failure )    
//          1 - update failure    
//          2 - update successful    
//          3 - same item present
//
//  Date: 2018/09/25
//  Version: 1.0
//
//  Make by M.H team
//
//////////////////////////////////////////////////////////////////////////
    include 'robotdb.php';

    // Check connection
    if ($GLOBALS['conn']->connect_error) {
        // database connect failure
        echo "0";
    } 
    else {
        // visitor data read from startIndexForRead to startIndexForRead + count
        if ( isset( $_GET['startIndexForRead'] ) ) {

            $startIndex = $_GET['startIndexForRead'];
            $countForRead = $_GET['countForRead'];

            $sql = "SELECT id, account, password, lastlogintime, blockvisitor, accesslink, temppassword FROM owner";   
            $result = $GLOBALS['conn']->query($sql);
            // read the data
            if ($result->num_rows > 0) {
                $index = 0;
                $indexCount = 0;
                $data = array();
                // output data of each row
                while( $row = $result->fetch_assoc() )  {
                    if ( $index >= $startIndex ) {
                        // make array
                        $data[] = array(
                            $row['id'],
                            $row['account'],
                            $row['password'],
                            $row['lastlogintime'],
                            $row['blockvisitor'],
                            $row['accesslink'],
                            $row['temppassword']
                        );
                        // check the count
                        $indexCount += 1;
                        if ( $indexCount >= $countForRead ) {
                            break;
                        }
                    }
                    $index += 1;
                }
                echo json_encode(array_values($data));
            }
            else {
                echo "1";
            }
        }
        // insert owner data by admin
        else if ( isset( $_GET['insert'] ) ) {   
            $account =  $_GET['account'];
            $password =  $_GET['password'];
            // make robot name
            for ( $ix = 1; $ix < 1000; $ix++ ) {
                $robotName = sprintf("%03d", $ix);
                // check same robot name
                $sql = "SELECT id FROM owner WHERE robotname = '$robotName'";
                $result = $GLOBALS['conn']->query($sql);
                if ($result->num_rows > 0)
                    continue;
                else {
                    $accesslink = "localhost/" . $robotName;
                    // insert
                    $sql = "INSERT INTO owner (
                        account, password, lastlogintime, blockvisitor,
                        accesslink, temppassword, status, onoffline, useaccount, robotname
                    ) 
                    VALUES ('$account', '$password', '', 0,
                        '$accesslink', '', 'normal', 'online', '', '$robotName'
                    )";
                    // write successful ?
                    if ($GLOBALS['conn']->query($sql) === false) {
                        echo "1";
                    } 
                    else {
                        echo "2";
                    }
                    break;
                }
            }
            if ( $ix >= 1000 ) 
                echo "1";
        }
        // get rows of  owner data
        else if ( isset( $_GET['getrows'] ) ) {
            $query = 'SELECT id FROM owner';
            $result = $GLOBALS['conn']->query($query);
            echo $result->num_rows;
        }
        // delete one rows of  owner data
        else if ( isset( $_GET['deleteRow'] ) ) {
            $deleteRow = $_GET['deleteRow'];
            $sql = "SELECT account FROM owner";   
            $result = $GLOBALS['conn']->query($sql);
            // read the data
            if ($result->num_rows > 0) {
                $index = 0;
                $delAccount = "";
                // output data of each row
                while( $row = $result->fetch_assoc() )  {
                    if ( $index >= $deleteRow ) {
                        $delAccount = $row['account'];
                        break;
                    }
                    else
                        $index += 1;
                }
                if( $delAccount != "" ) {
                    // delete
                    $sql = "DELETE FROM owner WHERE account = '$delAccount'";
                    if ( $GLOBALS['conn']->query($sql) == true )
                        echo "2";
                    else 
                        echo "1";
                }
                else
                    echo "1";
            }
            else
                echo "1";
        }
        // update one rows of  owner data
        else if ( isset( $_GET['updateRow'] ) ) {
            $modifyAccount = $_GET['account'];
            $modifyPassword = $_GET['password'];
                $updateRow = $_GET['updateRow'];
                $sql = "SELECT id FROM owner";   
                $result = $GLOBALS['conn']->query($sql);
                // read the data
                if ($result->num_rows > 0) {
                    $index = 0;
                    // output data of each row
                    while( $row = $result->fetch_assoc() )  {
                        if ( $index >= $updateRow ) {
                            $idx = $row['id'];
                            break;
                        }
                        else
                        $index += 1;
                    }
                    // update
                    $sql = "UPDATE owner SET account = '', account = '$modifyAccount', password = '$modifyPassword' WHERE id = '$idx'";
                    if ( $GLOBALS['conn']->query($sql) == true )
                        echo "2";
                    else 
                        echo "1";
                }
        }
        // db close
        $GLOBALS['conn']->close();   
    }
    exit;
?>
