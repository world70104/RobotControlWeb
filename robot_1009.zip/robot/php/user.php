<?php
/////////////////////////////////////////////////////////////////////////
//
//                          user.php 
//
//    login
//
//  return: 
//     if login
//          0 - no database( database connect failure )    
//          1 - successful in owner    
//          2 - successful in visitor    
//          3 - search failure
//          4 - no robot
//          5 - offline
//          6 - occupy
//          7 - private
//          8 - account using    
//          9 - temp password fail    

//         0n/offline, ""/robot name, normal/private 
//  Date: 2018/09/25
//  Version: 1.0
//
//  Make by M.H team
//
//////////////////////////////////////////////////////////////////////////
    include 'robotdb.php';

    // search status
    $GLOBALS['vAccount'] = 'no';
    $GLOBALS['vPassword'] = 'no';
    $GLOBALS['oAccount'] = 'no';
    $GLOBALS['oPassword'] = 'no';
    $GLOBALS['oTempPassword'] = 'no';
    $GLOBALS['oStatus'] = 0;

    // new account present check in visitor
    function checkVisitor( $account, $password ) {
        $sql = "SELECT account, password FROM visitor";   
        $result = $GLOBALS['conn']->query($sql);
        // read the data
        if ($result->num_rows > 0) {
            // output data of each row
            while( $row = $result->fetch_assoc() )  {
                // same account ?
                if( $row["account"] === $account ) {
                    $GLOBALS['vAccount'] = 'yes';
                    if ( $row["password"] === $password )
                        $GLOBALS['vPassword'] = 'yes';
                    break;
                }
            }
        }
    }

    // check in owner
    // ret - 0 : successful
    //       4 : no robot 
    //       5 : off line
    //       6: occupy 
    //       7: private
    //       8: in using account
    function checkOwner(  $account, $password, $temppassword, $useToRobot ) {
        // status check for visitor
        $sql = "SELECT id, account, password, lastlogintime, blockvisitor, accesslink, 
            temppassword, status, onoffline, useaccount, robotname FROM owner";   
        $result = $GLOBALS['conn']->query($sql);
        $GLOBALS['oStatus'] = 4;
        // read the data
        if ($result->num_rows > 0) {
            while( $row = $result->fetch_assoc() )  {
                // account using check ?
                if( $row["useaccount"] == $account ) {
                    $GLOBALS['oStatus'] = 8;
                    break;
                }
                // same robot name check?
                if( $row["robotname"] == $useToRobot ) {
                    $GLOBALS['oStatus'] = 0;
                    // same account?
                    if( $row["account"] == $account ) {
                        $GLOBALS['oAccount'] = 'yes';    
                    }
                    // same password?
                    if( $row["password"] == $password ) {
                        $GLOBALS['oPassword'] = 'yes';    
                    }
                    // same temp password?
                    if( $row["temppassword"] == $temppassword ) {
                        $GLOBALS['oTempPassword'] = 'yes';    
                    }
                    // robot oline status
                    if ( $row["onoffline"] == 'offline' ) {
                        $GLOBALS['oStatus'] = 5;
                    }     
                    // robot occupy
                    else if ( $row["useaccount"] != "" ) {
                        $GLOBALS['oStatus'] = 6;
                        $sqlBlockvisitor = $row["blockvisitor"];
                        $sqlBlockvisitor += 1;
                        if( $row["account"] == $account ) {
                            // update blockvisitor field 
                            $sql = "UPDATE owner SET 
                                blockvisitor = '$sqlBlockvisitor'
                                WHERE account = '$sqlAccount'";
                            $conn->query($sql);
                        }
                    }     
                    // robot in private
                    else if ( $row["status"] != 'normal' ) {
                        $GLOBALS['oStatus'] = 7;
                    }     
                }
            }
        }
    }

    function visitorOkProcess( $account, $useToRobot ) {
        // set the use count
        $sql = "UPDATE owner SET useaccount = '$account' WHERE robotname = '$useToRobot'";
        $GLOBALS['conn']->query($sql);

        // set last login time in visitor
        $date = date("Y-m-d h:i");    
        $sql = "UPDATE visitor SET lastlogintime = '$date' WHERE account = '$account'";
        $GLOBALS['conn']->query($sql);

        // set robots + 1
        // get robots
        $sql = "SELECT robots FROM visitor WHERE account = '$account'";   
        $result = $GLOBALS['conn']->query($sql);
        $preRobots = "";
        if ($result->num_rows > 0) {
            // output data of each row
            while( $row = $result->fetch_assoc() )  {
                $preRobots = $row["robots"];
                $preRobots += 1;
                break;
            }
        }
        // set robots
        if ( $preRobots != "" ) {
            $sql = "UPDATE visitor SET robots = '$preRobots' WHERE account = '$account'";
            $GLOBALS['conn']->query($sql);
        }
    }

    // db open
    // Check connection
    if ($GLOBALS['conn']->connect_error) {
        // database connect failure
        echo "0";
    } 
    else {
        // status init
        $GLOBALS['vAccount'] = 'no';
        $GLOBALS['vPassword'] = 'no';
        $GLOBALS['oAccount'] = 'no';
        $GLOBALS['oPassword'] = 'no';
        $GLOBALS['oTempPassword'] = 'no';
        $GLOBALS['oStatus'] = 0;    

        // login 
        if ( isset( $_GET['login'] ) ) {
            $account = $_GET['account'];
            $password = $_GET['password'];
            $tempPassword = $_GET['tempPassword'];
            $useToRobot = $_GET['useToRobot'];
            // visitor check
            checkVisitor( $account, $password );
            // owner check
            checkOwner( $account, $password, $tempPassword, $useToRobot );
//echo ( $GLOBALS['vAccount'] . $GLOBALS['vPassword'] . $GLOBALS['oAccount'] .
//$GLOBALS['oPassword'] . $GLOBALS['oTempPassword'] . $GLOBALS['oStatus'] );
            // in using account
            if ( $GLOBALS['oStatus'] == 8 ) {
                echo( "8" );
            }
            // occupy
            else if ( $GLOBALS['oStatus'] == 6 ) {
                echo( "6" );
            }
            // off line
            else if ( $GLOBALS['oStatus'] == 5 ) {
                echo( "5" );
            }
                // no robot
            else if ( $GLOBALS['oStatus'] == 4 ) {
                echo( "4" );
            }
            // Visiter account ok? 
            else if ( $GLOBALS['vAccount'] == 'yes' ) {
                // status ok
                if ( $GLOBALS['oStatus'] == 0 ) {
                    if ( $GLOBALS['vPassword'] == 'yes' ) {
                        visitorOkProcess( $_GET['account'], $_GET['useToRobot'] );
                        echo( "2" );
                    }
                    else 
                        echo( "3" );
                }
                // private
                else if ( $GLOBALS['oStatus'] == 7 ) {
                    if ( $GLOBALS['oTempPassword'] == 'yes' ) {
                        visitorOkProcess( $_GET['account'], $_GET['useToRobot'] );
                        echo( "2" );
                    }
                    else 
                        echo( "9" );
                }
            }
            else 
                echo( "3" );            
        }
        $GLOBALS['conn']->close();   
    }
?>