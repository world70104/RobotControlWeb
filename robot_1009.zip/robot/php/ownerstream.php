<?php
/////////////////////////////////////////////////////////////////////////
//
//                          ownerstream.php 
//
//    ownerstream
//
//  return: 
//     if use account init
//          0 - no database( database connect failure )    
//          1 - successful in use status init    
//          3 - failure    
//  Date: 2018/09/25
//  Version: 1.0
//
//  Make by M.H team
//
//////////////////////////////////////////////////////////////////////////
    include 'robotdb.php';

    $GLOBALS['isUsing'] = false;

    // db open
    // Check connection
    if ($GLOBALS['conn']->connect_error) {
        // database connect failure
        echo "0";
    } 
    else {
        // init the use account
        if ( isset( $_GET['initUseAccount'] ) ) {
            $useToRobot = $_GET['useToRobot'];
            $sql = "SELECT account, password, lastlogintime, blockvisitor, accesslink, temppassword, status, onoffline, useaccount, robotname FROM owner";   
            $result = $GLOBALS['conn']->query($sql);
            // read the data
            if ($result->num_rows > 0) {
                $isRow = 0;
                while( $row = $result->fetch_assoc() )  {
                    // same robot name check?
                    if( $row["robotname"] == $useToRobot ) {
                        // init the use count
                        $sql = "UPDATE owner SET useaccount = '' 
                            WHERE robotname = '$useToRobot'";
                        $conn->query($sql);
                        echo "1";
                        break;
                    }
                }
            }
        }
        // read temp password
        else if ( isset( $_GET['readTempPassword'] ) ) {
            $useToRobot = $_GET['useToRobot'];
            $sql = "SELECT temppassword, robotname FROM owner";   
            $result = $GLOBALS['conn']->query($sql);
            // read the data
            if ($result->num_rows > 0) {
                $isRow = 0;
                while( $row = $result->fetch_assoc() )  {
                    // same robot name check?
                    if(
                        ( $row["robotname"] == $useToRobot )
                    )  {
                            $isRow = 1;
                            echo $row["temppassword"];
                            break;
                    }
                }
                if ( $isRow != 1 ) {
                    echo "1";
                }
            }
            else 
                echo "1";
        }
        // write temp password
        else if ( isset( $_GET['writeTempPassword'] ) ) {
            $useToRobot = $_GET['useToRobot'];
            $sql = "SELECT robotname FROM owner";   
            $result = $GLOBALS['conn']->query($sql);
            // read the data
            if ($result->num_rows > 0) {
                $isRow = 0;
                while( $row = $result->fetch_assoc() )  {
                    // same robot name check?
                    if(
                        ( $row["robotname"] == $useToRobot )
                    )  {
                            $isRow = 1;
                            break;
                    }
                }
                // write the temp password
                if ( $isRow == 1 ) {
                    $tempPassword = $_GET['tempPassword'];
                    // init the use count
                    $sql = "UPDATE owner SET temppassword = '$tempPassword' WHERE robotname = '$useToRobot'";

                    $conn->query($sql);
                    echo "2";
                }
                else
                echo "1"; 
            }
            else
                echo "1";
        }
    }
    $GLOBALS['conn']->close();   
    exit;
?>