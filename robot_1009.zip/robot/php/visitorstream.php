<?php
/////////////////////////////////////////////////////////////////////////
//
//                          visitorstream.php 
//
//    visitorstream
//
//  return: 
//     if use account init
//          0 - no database( database connect failure )    
//          1 - successful in use status init    
//          3 - failure    
//  Date: 2018/09/25
//  Version: 1.0
//
//  Make by M.H team
//
//////////////////////////////////////////////////////////////////////////
    include 'robotdb.php';

    $GLOBALS['isUsing'] = false;
    // Check connection
    if ($GLOBALS['conn']->connect_error) {
        // database connect failure
        echo "0";
    } 
    else {
        // init the use account
        if ( isset( $_REQUEST['initUseAccount'] ) ) {
            $useToRobot = $_REQUEST['useToRobot'];
            $sql = "SELECT account, password, lastlogintime, blockvisitor, accesslink, temppassword, status, onoffline, useaccount, robotname FROM owner";   
            $result = $GLOBALS['conn']->query($sql);
            // read the data
            if ($result->num_rows > 0) {
                $isRow = 0;
                while( $row = $result->fetch_assoc() )  {
                    // same robot name check?
                    if(
                        ( $row["robotname"] == $useToRobot )
                    )  {
                            $isRow = 1;
                            break;
                    }
                }
                // init
                if ( $isRow == 1 ) {
                    // init the use count
                    $sql = "UPDATE owner SET useaccount = '' WHERE robotname = '$useToRobot'";

                    $GLOBALS['conn']->query($sql);
                    echo "1";
                }
            }
        }
    }
    $GLOBALS['conn']->close();   
    exit;
?>