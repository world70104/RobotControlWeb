<?php
/////////////////////////////////////////////////////////////////////////
//
//                          admin.php 
//
//    login
//
//  return: 0 - no database( database connect failure )    
//          1 - no record    
//          2 - modify successful    
//          3 - search failure    
//
//  Date: 2018/09/25
//  Version: 1.0
//
//  Make by M.H team
//
//////////////////////////////////////////////////////////////////////////
    include 'robotdb.php';

    // Check connection
    if ($GLOBALS['conn']->connect_error) {
        // database connect failure
        echo "0";
    } 
    else {
            $sql = "SELECT password FROM admin";   
            $result = $GLOBALS['conn']->query($sql);
            // read the data
            if ($result->num_rows > 0) {
                // output data of each row
                $row = $result->fetch_assoc();
                $newpassword = $_GET['newpassword1'];
                if( $row["password"] == $_GET['oldpassword'] ) {
                    $sql = "UPDATE admin SET password = '$newpassword' WHERE account = 'admin'";
                    if ( $result = $GLOBALS['conn']->query($sql) === true ) {
                        echo "2";
                    }
                    else {
                        echo "3";
                    }    
                }
                else {
                    echo "3";
                }
            }
            else {
                echo "1";
            }
        // db close
        $GLOBALS['conn']->close();   
    }
    exit;
?>