/////////////////////////////////////////////////////////////////////////
//
//                          visitorstream.js 
//
//    visitorstream
//
//  Date: 2018/09/25
//  Version: 1.0
//
//  Make by M.H team
//
//////////////////////////////////////////////////////////////////////////

function gotoFirstPage() {
    if (confirm("Do you really want to signup?")) {
        // if not remember, init cookie 
        var useToRobot = getCookie('useToRobot');
        if( getCookie( 'user_rememberMeCheck' ) != "yes" ) {
                // cookie setting
            setCookie( "user_account", "");
            setCookie( "user_password", "");
        }
        // init the use status
        $.get("/php/visitorstream.php",{ initUseAccount : "initUseAccount", useToRobot : useToRobot  } ,function(data) {
            window.location.href= "/" + useToRobot + "/index.html";  
        });
    }
}

function getCookie(c_name) {
    return localStorage.getItem(c_name);
}

function setCookie(c_name, value) {
    return localStorage.setItem(c_name, value);
}
