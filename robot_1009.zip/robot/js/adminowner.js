/////////////////////////////////////////////////////////////////////////
//
//                          adminowner.js 
//
//    adminowner
//
//  Date: 2018/09/25
//  Version: 1.0
//
//  ret:
//      if insert ?
//          0: - 
//
//  Make by M.H team
//
//////////////////////////////////////////////////////////////////////////

var RowsInPage = 5;
var ShowPagesInPageMoveList = 5;
var CurrentPage = 0;
var OwnerIdsInPage = [ 0, 0, 0, 0, 0 ];
var allRows = 0;
var FirstPageInPageMoveList = 0;

function initOwnerTableView() {
    // get row count
    var getrows = "getrows";
    $.get("/php/adminowner.php",{ getrows:getrows } ,function(data) {
        allRows = data;
        setCookie( 'allRows', allRows);
        setCookie( 'RowsInPage', 5);
        setCookie( 'ShowPagesInPageMoveList', 5);
        setCookie( 'CurrentPage', 0);
        setCookie( 'FirstPageInPageMoveList', 0);
    });
}

// add owner table
function addOwnerTable() {
    var ownerTable = document.getElementById("ownerTable");
    // current page
    CurrentPage = getCookie( 'CurrentPage');
    RowsInPage = getCookie( 'RowsInPage');
    var startIndexForRead = Number(CurrentPage) * Number(RowsInPage);
    // read data
    $.get("/php/adminowner.php",{ startIndexForRead:startIndexForRead,countForRead:RowsInPage } ,function(data) {
        if ( data === "0" ) {
            alert('Database error');
        }
        else if ( data === "1" ) {
        }
        else {
            var rows = JSON.parse(data);
            var rowCount = rows.length;
            // make a table
            // IE7 only supports appending rows to tbody
            var tbody = document.createElement("tbody");    
            // for each outer array row
            for (var i = 0 ; i < rowCount; i++) {
                var tr = document.createElement("tr"); 
                tr.setAttribute('class', 'bg-info');
                row = rows[ i ];
                // for each inner array cell
                // create td then text, append
                for (var j = 0; j < row.length + 3; j++) {
                    var td = document.createElement("td");
                    // modify for cell 0
                    if ( j == 0 ) {
                        var btn = document.createElement('input');
                        btn.type = 'button';
                        btn.id = startIndexForRead + i;
                        btn.value= "modify" ;
                        // modify function
                        btn.onclick = function(e) { 
                            var updateRow = e.target.id;
                            // index in table    
                            var ti = Number(updateRow) - Number(CurrentPage) * Number(RowsInPage);
                            ti += 1;
                            setCookie( 'updateRow', updateRow);
                            document.getElementById("modify-account").value = ownerTable.rows[ti].cells[3].innerHTML;
                            document.getElementById("modify-password").value = ownerTable.rows[ti].cells[4].innerHTML;

                            modifyScreen();
                        }
                        td.appendChild(btn);
                    }
                    // delete for cell 1
                    else if ( j == 1 ) {
                        var btn = document.createElement('input');
                        btn.type = 'button';
                        btn.id = startIndexForRead + i;
                        btn.value= "delete" ;
                        // delete function
                        btn.onclick = function(e) { 
                            var deleteRow = e.target.id;
                            if (confirm("Do you really want to delete?")) {
                                // delete ok ?
                                // delete row
                                $.get("/php/adminowner.php",{ deleteRow:deleteRow } ,function(data) {

                                    if ( data == 1 ) 
                                        alert("delete failure");
                                    else {
                                        // delete succcessful
                                        // row delete
                                        allRows = getCookie( 'allRows' );
                                        if ( allRows > 0 ) {
                                            allRows = Number(allRows) - 1;
                                            setCookie( 'allRows', allRows);
                                        }
                                        document.getElementById("ownerRowsShow").innerHTML = allRows + " entries";
                                        // show all rows
                                        getRows();
                                        // show page move list
                                        // remove page move list
                                        if ( CurrentPage != 0 ) {
                                            var RowsInPage = getCookie( 'RowsInPage' );
                                            if ( deleteRow == allRows ) {
                                                var mod = allRows % RowsInPage;
                                                if( mod == 0  ) {
                                                    CurrentPage -= 1;
                                                    setCookie( 'CurrentPage', CurrentPage);
                                                }
                                            }
                                        }
                                        removePageMoveList();
                                        setPageMoveList();
                                        // show table
                                        deleteOwnerTableRows();
                                        addOwnerTable();
                                        location.reload(true);
                                    } 
                                });
                            }
                        }
                        td.appendChild(btn);
                    }
                    // no for cell 3
                    else if ( j == 2 )  {
                        var txt = document.createTextNode( startIndexForRead + i + 1 );
                        td.appendChild(txt);
                    }
                    else {
                        // id check
                        if ( j == 3 ) {
                            OwnerIdsInPage[ i ] = row[j-3];
                            continue;
                        }
                        else {
                            var txt = document.createTextNode(row[j-3]);
                            td.appendChild(txt);
                        }
                    }
                    tr.appendChild(td);
                }            
                // append row to table
                // IE7 requires append row to tbody, append tbody to table
                tbody.appendChild(tr);
                ownerTable.appendChild(tbody);
            }
        }
    })
}

function modifyAccount() {
    // update ok ?
    var updateRow = getCookie( 'updateRow');
    var account = document.getElementById("modify-account").value;
    var password = document.getElementById("modify-password").value;   
    var letterNumber = /^(\d|[a-zA-Z]){4,16}$/;
    if ( account.length == 0  ) {
        alert( "account is empty" );
    }                     
    else if ( password.length == 0  ) {
        alert( "password is empty" );
    }             
    else if (!password.match( letterNumber )) {
        alert( "The password is 4-16 digits or letters" );
    }
    else {        
        // update row
        $.get("/php/adminowner.php",{ updateRow : updateRow, account : account,
            password : password   } ,function(data) {
            if ( data == 1 ) 
                alert("update failure");
            else if ( data == 3 )
                alert( 'present the same account' );
            else {
                // show table
                deleteOwnerTableRows();
                addOwnerTable();
            } 
        });
    }
    normalScreen();
}

function normalScreen() {
/*
    var addAccountBar = document.getElementById("add-account-bar");
    addAccountBar.style.display = 'block';
    ownerTable.style.display = 'block';
    var addAccountBar = document.getElementById("page-move-bar");
    addAccountBar.style.display = 'block';;

    var addAccountBar = document.getElementById("modify-account-bar");
    addAccountBar.style.display = 'none';;
*/
    window.location.reload();
}

function modifyScreen() {
    var addAccountBar = document.getElementById("add-account-bar");
    addAccountBar.style.display = 'none';
    ownerTable.style.display = 'none';
    var addAccountBar = document.getElementById("page-move-bar");
    addAccountBar.style.display = 'none';;

    var addAccountBar = document.getElementById("modify-account-bar");
    addAccountBar.style.display = 'block';;
}

function addNewAccount() {
    var account = document.getElementById("account").value;
    var password = document.getElementById("password").value;
    // check validation
    if (account.length == 0 ) {
        alert( 'Please enter the account ' );    
    }
    else if (password.length == 0 ) {
        alert( 'Please enter the password ' );    
    }
    else {
        // insert data
        var insert = "insert";
        $.get("/php/adminowner.php",{ insert:insert, account:account, password:password } ,function(data) {
            if ( data == 0 )
                alert( 'Database error' );
            else if ( data == 1 )
                alert( 'data add error' );
            else {

                // insert successful
                // row inc
                allRows = getCookie( 'allRows' );
                allRows = Number(allRows) + 1;
                setCookie( 'allRows', allRows);
                document.getElementById("ownerRowsShow").innerHTML = allRows + " entries";

                deleteOwnerTableRows();
                addOwnerTable();

                removePageMoveList();
                setPageMoveList();
            }
        });
        location.reload(true);
    }
}

// delete all rows in owner table
function deleteOwnerTableRows() {
    var ownerTable = document.getElementById("ownerTable");
    while(ownerTable.rows.length > 1) {
        ownerTable.deleteRow(1);
    }
}

function getRows() {
    // get row count
    allRows = getCookie( 'allRows' );
    document.getElementById("ownerRowsShow").innerHTML = allRows + " entries";
}

function removePageMoveList() {
    // Get the <ul> element with id="myList"
    var list = document.getElementById("pageMoveList");

    // As long as <ul> has a child node, remove it
    while (list.hasChildNodes()) {   
        list.removeChild(list.firstChild);
    }
}

function setPageMoveList() {

    // read pos information
    allRows = getCookie( 'allRows' );

    RowsInPage = getCookie( 'RowsInPage' );
    ShowPagesInPageMoveList = getCookie( 'ShowPagesInPageMoveList' );
    CurrentPage = getCookie( 'CurrentPage' );
    FirstPageInPageMoveList = getCookie( 'FirstPageInPageMoveList' );

    // get the all pages
    var allPages = Math.floor( allRows / RowsInPage );
    var addPage = allRows - ( allPages * RowsInPage );
    if ( addPage != 0  ) {
        allPages += 1;
    }

    var ul = document.getElementById("pageMoveList");
    // all page < ShowPagesInPageMoveList
    if ( allPages <= ShowPagesInPageMoveList ) {
        for( var idxPage = 0; idxPage < allPages; idxPage++ ) {
            var li = document.createElement("li");
            var a = document.createElement("a");
            var content = Number(FirstPageInPageMoveList) + Number(1) + Number(idxPage);
            a.textContent = content;
            a.setAttribute('href', "#");
            a.setAttribute("id", content);
            li.appendChild(a);
            li.setAttribute("id", content);
            ul.appendChild(li);
        }
    }
    else {
        if ( FirstPageInPageMoveList != 0 ) {
            // <<
            var li = document.createElement("li");
            var a = document.createElement("a");
            var content = '<<';
            a.textContent = content;
            a.setAttribute('href', "#");
            a.setAttribute("id", content);
            li.appendChild(a);    
            ul.appendChild(li);
        }
        for( var idxPage = 0; idxPage < ShowPagesInPageMoveList; idxPage++ ) {
            var li = document.createElement("li");
            var a = document.createElement("a");
            var content = Number(FirstPageInPageMoveList) + Number(1) + Number(idxPage);
            a.textContent = content;
            a.setAttribute('href', "#");
            a.setAttribute("id", content);
            li.appendChild(a);
            ul.appendChild(li);
        }
        if ( Number(FirstPageInPageMoveList) + Number(ShowPagesInPageMoveList) < 
            Number(allPages) ) {
            // >>
            var li = document.createElement("li");
            var a = document.createElement("a");
            var content = '>>';
            a.textContent = content;
            a.setAttribute('href', "#");
            a.setAttribute("id", content);
            li.appendChild(a);    
            ul.appendChild(li);
        }
    }
    ul.addEventListener('click', function(e) {
        // read pos information
        allRows = getCookie( 'allRows' );
        RowsInPage = getCookie( 'RowsInPage' );
        ShowPagesInPageMoveList = getCookie( 'ShowPagesInPageMoveList' );
        FirstPageInPageMoveList = getCookie( 'FirstPageInPageMoveList' );
        // page move
        // get the all pages
        var allPages = Math.floor( allRows / RowsInPage );
        var addPage = allRows - ( allPages * RowsInPage );
        if ( addPage != 0  ) {
            allPages += 1;
        }
        var amountPageMove = Math.round( ShowPagesInPageMoveList / 2 );
        // preview
        if( e.target.id == '<<' ) {
            FirstPageInPageMoveList -= amountPageMove;
            if ( FirstPageInPageMoveList < 0 )  {
                FirstPageInPageMoveList = 0;
            }
            // set first page in page move list 
            setCookie( 'FirstPageInPageMoveList', FirstPageInPageMoveList);

            // remove page move list
            removePageMoveList();
            setPageMoveList();
        }
        // after
        else if( e.target.id == '>>' ) {
            FirstPageInPageMoveList = Number(FirstPageInPageMoveList) +  Number(amountPageMove);
            var endPage =  Number(FirstPageInPageMoveList) +  Number(ShowPagesInPageMoveList);
            if ( endPage > allPages ) {
                FirstPageInPageMoveList = Number(allPages) - Number(ShowPagesInPageMoveList);
            }
            // set first page in page move list 
            setCookie( 'FirstPageInPageMoveList', FirstPageInPageMoveList);

            // remove page move list
            removePageMoveList();
            setPageMoveList();
        }
        // page number
        else {
            CurrentPage = getCookie( 'CurrentPage' );
            var movePage =   Number( e.target.id ) - 1;
            // same page ?
            if ( CurrentPage != movePage ) {
                setCookie( 'CurrentPage', movePage);
                deleteOwnerTableRows();
                addOwnerTable();
            }
        }
    });
}

function getCookie(c_name) {
    return localStorage.getItem(c_name);
}

function setCookie(c_name, value) {
    return localStorage.setItem(c_name, value);
}

function gotoFirstPage() {
    if (confirm("Do you really want to signup?")) {
        // if not remember, init cookie 
        if( getCookie( 'admin_rememberMeCheck' ) != "yes" ) {
                // cookie setting
            setCookie( "admin_account", "");
            setCookie( "admin_password", "");
        }
        // cookie setting
        window.location.href="/admin.html";  
    }
}
