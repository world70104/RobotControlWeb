/////////////////////////////////////////////////////////////////////////
//
//                          ownerstream.js 
//
//    ownerstream
//
//  Date: 2018/09/25
//  Version: 1.0
//
//  Make by M.H team
//
//////////////////////////////////////////////////////////////////////////

var websocket = null;
var account = "";
var plat = "pc";

// if (reg.test(plat) > 0) {
//     plat = "Android";
// } else {
//     plat = "pc";
// }

function ownerFirstProcess() {
    // init action
//    websocketInit();
    // left button
    var $btnl = [].slice.call( document.querySelectorAll( '.btn.btn-left.btn-circle' ) );
    $btnl.map( function ( btn ) {    
      btn.addEventListener( 'mousedown', function ( e ) {
        left_b_mouseDown();
      } );
      btn.addEventListener( 'mouseup', function ( e ) {
        left_b_mouseUp();
      } );      
    } );
    // up button
    var $btnu = [].slice.call( document.querySelectorAll( '.btn.btn-up.btn-circle' ) );
    $btnu.map( function ( btn ) {    
      btn.addEventListener( 'mousedown', function ( e ) {
        up_b_mouseDown();
      } );
      btn.addEventListener( 'mouseup', function ( e ) {
        up_b_mouseUp();
      } );      
    } );
    // right button
    var $btnr = [].slice.call( document.querySelectorAll( '.btn.btn-right.btn-circle' ) );
    $btnr.map( function ( btn ) {    
      btn.addEventListener( 'mousedown', function ( e ) {
        right_b_mouseDown();
      } );
      btn.addEventListener( 'mouseup', function ( e ) {
        right_b_mouseUp();
      } );      
    } );
    // down button
    var $btnd = [].slice.call( document.querySelectorAll( '.btn.btn-down.btn-circle' ) );
    $btnd.map( function ( btn ) {    
      btn.addEventListener( 'mousedown', function ( e ) {
        down_b_mouseDown();
      } );
      btn.addEventListener( 'mouseup', function ( e ) {
        down_b_mouseUp();
      } );      
    } );
    // w button
    var $btnw = [].slice.call( document.querySelectorAll( '.btn.btn-w.btn-circle' ) );
    $btnw.map( function ( btn ) {    
      btn.addEventListener( 'mousedown', function ( e ) {
        w_b_mouseDown();
      } );
      btn.addEventListener( 'mouseup', function ( e ) {
        w_b_mouseUp();
      } );      
    } );
    // s button
    var $btns = [].slice.call( document.querySelectorAll( '.btn.btn-s.btn-circle' ) );
    $btns.map( function ( btn ) {    
      btn.addEventListener( 'mousedown', function ( e ) {
        s_b_mouseDown();
      } );
      btn.addEventListener( 'mouseup', function ( e ) {
        s_b_mouseUp();
      } );      
    } );    
    // key down
    $("body").keydown(function (event) {
        // left
        if (event.keyCode == "37") {
            document.getElementById("left_b").style.background='#ff0000';
            left_b_mouseDown();
        }
        // up
        else if (event.keyCode == "38") {
            document.getElementById("up_b").style.background='#ff0000';
            up_b_mouseDown();
        }
        // right
        else if (event.keyCode == "39") {
            document.getElementById("right_b").style.background='#ff0000';
            right_b_mouseDown();
        }
        // down
        else if (event.keyCode == "40") {
            document.getElementById("down_b").style.background='#ff0000';
            down_b_mouseDown();
        }
        // w
        else if (event.keyCode == "87") {
            document.getElementById("w_b").style.background='#ff0000';
            w_b_mouseDown();
        }
        // s
        else if (event.keyCode == "83") {
            document.getElementById("s_b").style.background='#ff0000';
            s_b_mouseDown();
        }
        // k ( left + up )
        else if (event.keyCode == "75") {
            document.getElementById("left_b").style.background='#ff0000';
            document.getElementById("up_b").style.background='#ff0000';
            k_b_mouseDown();
        }
        // m ( right + up  )
        else if (event.keyCode == "77") {
            document.getElementById("right_b").style.background='#ff0000';
            document.getElementById("up_b").style.background='#ff0000';
            m_b_mouseDown();
        }
    });
    // key up
    $("body").keyup(function (event) {
        // left
        if (event.keyCode == "37") {// keyCode=13 enter
            document.getElementById("left_b").style.background='#ffffff';
            left_b_mouseUp();
        }
        // up
        else if (event.keyCode == "38") {
            document.getElementById("up_b").style.background='#ffffff';
            up_b_mouseUp();
        }
        // right
        else if (event.keyCode == "39") {
            document.getElementById("right_b").style.background='#ffffff';
            right_b_mouseUp();
        }
        // down
        else if (event.keyCode == "40") {
            document.getElementById("down_b").style.background='#ffffff';
            down_b_mouseUp();
        }
        // w
        else if (event.keyCode == "87") {
            document.getElementById("w_b").style.background='#ffffff';
            w_b_mouseUp();
        }
        // s
        else if (event.keyCode == "83") {
            document.getElementById("s_b").style.background='#ffffff';
            s_b_mouseUp();
        }
        // k ( left + up )
        else if (event.keyCode == "75") {
            document.getElementById("left_b").style.background='#ffffff';
            document.getElementById("up_b").style.background='#ffffff';
            k_b_mouseUp();
        }
        // m ( right + up  )
        else if (event.keyCode == "77") {
            document.getElementById("right_b").style.background='#ffffff';
            document.getElementById("up_b").style.background='#ffffff';
            m_b_mouseUp();
        }
    });
}

function gotoFirstPage() {
    if (confirm("Do you really want to signup?")) {
        // if not remember, init cookie 
        var useToRobot = getCookie('useToRobot');
        if( getCookie( 'user_rememberMeCheck' ) != "yes" ) {
                // cookie setting
            setCookie( "user_account", "");
            setCookie( "user_password", "");
        }
        // init the use status
        $.get("/php/ownerstream.php",{ initUseAccount : "initUseAccount", useToRobot : useToRobot  } ,function(data) {
            window.location.href= "/index.html";  
        });
    }
}

// generate 8 digits + letters
function genTempPassword() {
    var tempPass = "";
    var possible = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
    for (var i = 0; i < 8; i++)
        tempPass += possible.charAt(Math.floor(Math.random() * possible.length));
    document.getElementById("tempPasswordLabel").innerHTML = tempPass;
    writeTempPassword( tempPass );
}

function readTempPassword() {
    var useToRobot = getCookie('useToRobot');
    var readTempPassword = "readTempPassword";
    // read the temp password
    $.get("/php/ownerstream.php",{readTempPassword:readTempPassword, useToRobot:useToRobot} ,function(data) {
        if ( data == 1 ) {
            document.getElementById("tempPasswordLabel").innerHTML = "";
        }
         else {
            document.getElementById("tempPasswordLabel").innerHTML = data;
        }
    });
}

function writeTempPassword( tempPassword ) {
    var useToRobot = getCookie('useToRobot');
    var writeTempPassword = 'writeTempPassword';
    // read the temp password
    $.get("/php/ownerstream.php",{ writeTempPassword : writeTempPassword, useToRobot : useToRobot, 
        tempPassword : tempPassword } ,function(data) {
        if ( data == 1 ) {
            alert("failure the tempaeray password save");
        }
    });
}

function getCookie(c_name) {
    return localStorage.getItem(c_name);
}

function setCookie(c_name, value) {
    return localStorage.setItem(c_name, value);
}

function autoCheck() {
    // Get the checkbox
    var checkBox = document.getElementById("autoCheck");
    if (checkBox.checked == true) {
        websocketSend("5");
        setCookie("owner_autoCheck", "yes");
    }
    else {
        websocketSend("6");
        setCookie("owner_autoCheck", "no");
    }
}

function websocketInit() {

    // get the account
    account = getCookie( "user_account");

//    window.onload = init;
    if ("WebSocket" in window) {
        // console.log(window.location.host);
        websocket = new WebSocket("ws://" + window.location.host
            + ":9000/Websocket/?account=" + account + "&platform=" + plat);
    } else {
        var id = document.getElementById("error_text");
        id.style.color = "red";
        id.innerHTML = "Not Supported WebSocket";
    }
    websocket.onopen = function (event) {
        // id= event.data;
        this.send("account:" + plat + "," + account);
        startHeartBeat();
        // window.setInterval(websocketSend("keepAliveTimer"),5000);
    };
    websocket.onmessage = function (event) {
        var msg = event.data;
        var id = document.getElementById("error_text");
        id.style.color = "white";
        id.innerHTML = msg;
        if (msg.indexOf("Warning") >= 0) {
            id.innerHTML = msg;
            //            unloginToggle();
        }
    };
    websocket.onclose = function (event) {
        var id = document.getElementById("error_text");
        id.style.color = "red";
        id.innerHTML = "Connection interrupted,please refresh later";
    };
    websocket.onerror = function (event) {
    }
}

function startHeartBeat() {
    setInterval(function () {
        websocketSend("Still here")
    }, 5000);
}

var preMsg = "";
function websocketSend(msg) {
    if (msg.match("^\\d*$")) {
        if (msg != preMsg) {
            websocket.send("order:" + account + ":" + msg);
            preMsg = msg;
        }
    } else {
        websocket.send(msg);
    }
}
// left
function left_b_mouseDown() {
//    websocketSend("3");
    var id = document.getElementById("error_text");
    id.style.color = "white";
    id.innerHTML = "left u";
}
function left_b_mouseUp() {
//    websocketSend("5");
    var id = document.getElementById("error_text");
    id.style.color = "white";
    id.innerHTML = "left d";
}
// up
function up_b_mouseDown() {
//    websocketSend("1");
    var id = document.getElementById("error_text");
    id.style.color = "white";
    id.innerHTML = "up u";
}
function up_b_mouseUp() {
//    websocketSend("5");
    var id = document.getElementById("error_text");
    id.style.color = "white";
    id.innerHTML = "up d";
}
// right
function right_b_mouseDown() {
//    websocketSend("4");
    var id = document.getElementById("error_text");
    id.style.color = "white";
    id.innerHTML = "right u";
}
function right_b_mouseUp() {
//    websocketSend("5");
    var id = document.getElementById("error_text");
    id.style.color = "white";
    id.innerHTML = "right d";
}
// down
function down_b_mouseDown() {
//    websocketSend("2");
    var id = document.getElementById("error_text");
    id.style.color = "white";
    id.innerHTML = "down u";
}
function down_b_mouseUp() {
//    websocketSend("5");
    var id = document.getElementById("error_text");
    id.style.color = "white";
    id.innerHTML = "down d";
}
// w
function w_b_mouseDown() {
//    websocketSend("9");
    var id = document.getElementById("error_text");
    id.style.color = "white";
    id.innerHTML = "w u";
}
function w_b_mouseUp() {
//    websocketSend("11");
    var id = document.getElementById("error_text");
    id.style.color = "white";
    id.innerHTML = "w d";
}
// s
function s_b_mouseDown() {
//    websocketSend("10");
    var id = document.getElementById("error_text");
    id.style.color = "white";
    id.innerHTML = "s u";
}
function s_b_mouseUp() {
//    websocketSend("11");
    var id = document.getElementById("error_text");
    id.style.color = "white";
    id.innerHTML = "s d";
}
// k ( left + up ) 
function k_b_mouseDown() {
//    websocketSend("7");
    var id = document.getElementById("error_text");
    id.style.color = "white";
    id.innerHTML = "u+l u";
}
function k_b_mouseUp() {
//    websocketSend("5");
    var id = document.getElementById("error_text");
    id.style.color = "white";
    id.innerHTML = "u+l d";
}
// m ( right + up  )
function m_b_mouseDown() {
//    websocketSend("8");
    var id = document.getElementById("error_text");
    id.style.color = "white";
    id.innerHTML = "u+r u";
}
function m_b_mouseUp() {
//    websocketSend("5");
    var id = document.getElementById("error_text");
    id.style.color = "white";
    id.innerHTML = "u+r d";
}
