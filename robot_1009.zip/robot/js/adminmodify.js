/////////////////////////////////////////////////////////////////////////
//
//                          adminmodify.js 
//
//    admin password modify
//
//  Date: 2018/09/25
//  Version: 1.0
//
//  Make by M.H team
//
//////////////////////////////////////////////////////////////////////////

function onModify() {
   // get the parameter
    var account = 'admin';
    var oldpassword = document.getElementById("oldpassword").value;
    var newpassword1 = document.getElementById("newpassword1").value;
    var newpassword2 = document.getElementById("newpassword2").value;
    // input validate check ?
    if ( oldpassword.length == 0 ) {
        document.getElementById("error_text").innerHTML = "Please the old password";
    }
    else {
        if (            
            ( newpassword1.length == 0 ) ||
            ( newpassword2.length == 0 )
        ) {
            document.getElementById("error_text").innerHTML = "Please the new password";
        }
        else {
            if ( newpassword1 != newpassword2 ) {
                document.getElementById("error_text").innerHTML = "It is differrent the two new password";
            }
            else {
                var result = "";
                // call index.php
                    $.get("/php/adminmodify.php",{ oldpassword:oldpassword, newpassword1:newpassword1 } ,function(data) {
                    if ( data == "0" ) {
                        result = "No database.";
                    }
                    else if ( data == "1" ) {
                        result = "No database record.";
                    }
                    else if ( data == "2" ) {
                        result = "";
                        alert( "admin password is successfully modified" );
                    }
                    else if ( data == "3" ) {
                        result = "mistake admin password.";
                    }
                    document.getElementById("error_text").innerHTML = result;
                });
            }
        }
    }  
}

function gotoFirstPage() {
    if( getCookie( 'admin_rememberMeCheck' ) != "yes" ) {
        // cookie setting
        setCookie( "admin_account", "");
        setCookie( "admin_password", "");
    }
    window.location.href="/admin.html";  
}

function getCookie(c_name) {
    return localStorage.getItem(c_name);
}

function setCookie(c_name, value) {
    return localStorage.setItem(c_name, value);
}

