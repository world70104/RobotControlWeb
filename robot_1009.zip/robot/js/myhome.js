//红色p动画
$('.loading').animate({'width':'100%'},3000);

//取消修改密码
$('.btn-qx').click(function(){
    console.log(1232132);
    $('input').val("");
    $('.error_text').html("");
});
$('input').focus(function(){
	$(".error_text").html("");
	
});
//修改密码
$('.btn-tj').click(function(){
   var hobby =$('.hobby').val().trim();
   var phone =$('.phone').val().trim();
   var new_pas=$('.new_pas').val().trim();
   var re_pas=$('.re_pas').val().trim();
   var regPwd = /^(\d|[a-zA-Z]){4,16}$/;

    if (hobby == "") {
        $('.error_text').html('The contents of the input can not be empty!');
        return false;
    }
    if (phone == "") {
        $('.phone').html('phone can not be blank!');
        return false;
    }
    if (new_pas == "") {
        $('.error_text').html('password can not be blank!');
        return false;
    }
    else if (!regPwd.test(new_pas)) {
        $('.error_text').html('The password is 4-16 digits or letters!');
        return false;
    }
    if (re_pas == "") {
        $('.error_text').html('password can not be blank!');
        return false;
    }
    if (re_pas!=new_pas){
        $('.error_text').html('The passwords entered twice are not the same!');
        return false;
    }

    $.getJSON("/reset",{
    	hobby:hobby,
        account:phone,
        new_password:re_pas
    },function (r, s) {
        if(s=="success"){
        	if(r['status']){
        		 alert("password has been updated!");
                 $.getJSON("/sign_out",function(r,s){});
                 window.location.href="index.html";
        	}else{
        		alert(r['message']);
        	}
        }else{
            console.log("Net error!")
        }
    })
});