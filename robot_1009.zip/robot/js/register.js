/////////////////////////////////////////////////////////////////////////
//
//                          register.js 
//
//    register
//
//  Date: 2018/09/25
//  Version: 1.0
//
//  Make by M.H team
//
//////////////////////////////////////////////////////////////////////////

var adminAccount = "admin";
var verifyTimeCount = 60;
var milliSecond = 1000;
var result = "";
var verifyTimer;
var verifyCode;
// register
function onRegister() {
    // get the parameter
    var account = document.getElementById("account").value.trim();
    var password = document.getElementById("password").value.trim();
    var confirmPassword = document.getElementById("confirmPassword").value;
   // account check
   result = "";
    if ( account == '' ) {
        result = "Please enter account.";
    }
    else {
        // account == 'admin'
        if ( account == adminAccount ) {
            result = "'admin' account can't not register.";
        }
        else {
            // account valid check
            if ( checkAccountValid( account ) == true ) {
                // password check
                var letterNumber = /^(\d|[a-zA-Z]){4,16}$/;
                if ( password.length == 0 ) {
                    result = "Please enter password.";
                }
                else if (!password.match( letterNumber )) {
                    result = "The password is 4-16 digits or letters";
                }
                else {
                    // confirm password check
                    if ( confirmPassword.length == 0 ) {
                        result = "Please enter confirm password.";
                    }
                    else {
                        // matching password
                        if ( password == confirmPassword ) {
                            document.getElementById("error_text").innerHTML = "";
                            document.getElementById("account_div").style.display = 'none';
                            document.getElementById("password_div").style.display = 'none';
                            document.getElementById("confirmPassword_div").style.display = 'none';
                            document.getElementById("register_div").style.display = 'none';
                            // enable the verify     
                            document.getElementById("verify_div").style.display = 'block';
                            document.getElementById("confirm_div").style.display = 'block';
                            document.getElementById("verifyTimeTxt").innerHTML = "60s require the Verify code";  
                            // verify code( 5 digits ) 
                            verifyCode =  Math.floor(Math.random()*90000) + 10000;
                            verifyTimeCount = 60;
                            verifyTimer = setInterval(verifyTimerFunc, milliSecond );
                            // send verify code SMS
                            sendSMS();
                        }
                        else {
                            result = "password and confirm password are different.";
                        }
                    }
                }
            }
        }
    }
    document.getElementById("error_text").innerHTML = result;
 }

// verify timer
function verifyTimerFunc() {
    if ( verifyTimeCount > 0 ) {
        // 1 second ?
        verifyTimeCount -=1;
        document.getElementById("verifyTimeTxt").innerHTML = verifyTimeCount + "s require the Verify code";
    }  
    else {
        document.getElementById("error_text").innerHTML = "Verify time out.";
    }
}      

// valid check account
function checkAccountValid( account ) {
    var ret = false;
    // number ?
    if ( isNumeric( account ) ) {
        if ( account.length >= 7 ) {
            ret = true;
        }
        else {
            result = "phone number has to be min 7 digits.";
        }
    }
    else {
        // check the email
        if ( account.includes('@', 0) == true ) {
            ret = true;
        }
        else {
            result = "account is not email format.";
        }
    }
    return ret;
}
// check number
function isNumeric(num){
  return !isNaN(num)
}

function getCookie(c_name) {
    return localStorage.getItem(c_name);
}

function onConfirm() {
    var verifyInput = document.getElementById("verifyInput").value;
    // verify code check
    if( verifyInput == verifyCode ) {
        // if successful?
        clearInterval(verifyTimer);
        // register &  go to index.html
        // call register.php
        $.get("/php/register.php",{ account:account,password:password } ,function(data) {
            // register successful ?
            if ( data == "0" ) {
                result = "No database.";
            }
            else if ( data == "1" ) {
                                    result = "Present account.";
            }
            else if ( data == "3" ) {
                                    result = "Register failure.";
            }
            else {
                // register ok?
                result = "";
                $useToRobot = getCookie('useToRobot');
                window.location.href= '../' +  $useToRobot + '/' + "index.html";
            }
            document.getElementById("error_text").innerHTML = result;
        });
    }
    else if( verifyInput.length == 0 ) {
        document.getElementById("error_text").innerHTML = "Please enter the verify code";
    }
    else {
        document.getElementById("error_text").innerHTML = "It is bad verify code";
    }
}

function onResend() {
    document.getElementById("error_text").innerHTML = "";
    verifyCode =  Math.floor(Math.random()*90000) + 10000;
    verifyTimeCount = 61;
    // send verify code SMS
    sendSMS();
}

function sendSMS() {
    var account = document.getElementById("account").value;
    if( isNaN( account ) ) {
        // email ?
        $.get("/php/email.php",{ receiver:account,verifycode:verifyCode } ,function(data) {    
        });  
    }  
    else {
        // mobile 
        // send mobile SMS
        var sendSMS = "sendSMS";
        $.get("/php/register.php",{ sendSMS:sendSMS,verifycode:verifyCode } ,function(data) {    
            alert(data);
        });  
    }
}

function gotoFirstPage() {
    $user_kind = getCookie('user_kind');
    var useToRobot = getCookie('useToRobot');
    // return by visitor
    if( $user_kind == 'visitor' ) 
        window.location.href= "/" + useToRobot;  
    else
        window.location.href= "/index.html";  
}
