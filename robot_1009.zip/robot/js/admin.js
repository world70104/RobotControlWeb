/////////////////////////////////////////////////////////////////////////
//
//                          admin.js 
//
//    admin login
//
//  Date: 2018/09/25
//  Version: 1.0
//
//  Make by M.H team
//
//////////////////////////////////////////////////////////////////////////
//  
// login
//
function onLogin() {
   // get the parameter
    var account = 'admin';
    var password = document.getElementById("password").value;
    var result = "";
    // check parameter
        if ( password.length == 0 ) {
            document.getElementById("error_text").innerHTML = 'plaease the password';
        }  
        else {
            // call admin.php
            $.get("/php/admin.php",{ password:password } ,function(data) {
                if ( data == "0" ) {
                    result = "No database.";
                }
                else if ( data == "1" ) {
                    result = "No database record.";
                }
                else if ( data == "2" ) {
                    result = "";
                    // cookie setting
                    setCookie("admin_account", account);
                    setCookie("admin_password", password);
                    window.location.href= '/html/adminvisitor.html';
                }
                else if ( data == "3" ) {
                    result = "mistake admin password.";
                }
                document.getElementById("error_text").innerHTML = result;
            });
        }          
}

function rememberCheck() {
    // Get the checkbox
    var checkBox = document.getElementById("rememberMe");
    if (checkBox.checked == true)
        setCookie("admin_rememberMeCheck", "yes");
    else
        setCookie("admin_rememberMeCheck", "no");
}

function gotoFirstPage() {
    window.location.href= "/admin.html";
}

function getCookie(c_name) {
    return localStorage.getItem(c_name);
}

function setCookie(c_name, value) {
    return localStorage.setItem(c_name, value);
}
