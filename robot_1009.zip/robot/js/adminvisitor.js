/////////////////////////////////////////////////////////////////////////
//
//                          adminvisitor.js 
//
//    adminvisitor
//
//  Date: 2018/09/25
//  Version: 1.0
//
//  ret:
//      if insert ?
//          0: - 
//
//  Make by M.H team
//
//////////////////////////////////////////////////////////////////////////

var RowsInPageVisitor = 5;
var ShowPagesInPageMoveListVisitor = 5;
var CurrentPageVisitor = 0;
var allRowsVisitor = 0;
var FirstPageInPageMoveListVisitor = 0;

function initVisitorTableView() {
    // get row count
    var getrows = "getrows";
    $.get("/php/adminvisitor.php",{ getrows:getrows } ,function(data) {
        allRowsVisitor = data;
        setCookie( 'allRowsVisitor', allRowsVisitor);
        setCookie( 'RowsInPageVisitor', 5);
        setCookie( 'ShowPagesInPageMoveListVisitor', 5);
        setCookie( 'CurrentPageVisitor', 0);
        setCookie( 'FirstPageInPageMoveListVisitor', 0);
    });
}

// add owner table
function addVisitorTable() {
    var visitorTable = document.getElementById("visitorTable");
    // current page
    CurrentPageVisitor = getCookie( 'CurrentPageVisitor');
    RowsInPageVisitor = getCookie( 'RowsInPageVisitor');
    var startIndexForRead = Number(CurrentPageVisitor) * Number(RowsInPageVisitor);
    // read data
    $.get("/php/adminvisitor.php",{ startIndexForRead:startIndexForRead,countForRead:RowsInPageVisitor } ,function(data) {
        if ( data === "0" ) {
            alert('Database error');
        }
        else if ( data === "1" ) {
        }
        else {
            var rows = JSON.parse(data);
            var rowCount = rows.length;
            // make a table
            // IE7 only supports appending rows to tbody
            var tbody = document.createElement("tbody");    
            // for each outer array row
            for (var i = 0 ; i < rowCount; i++) {
                var tr = document.createElement("tr"); 
                tr.setAttribute('class', 'bg-info');
                row = rows[ i ];
                // for each inner array cell
                // create td then text, append
                for (var j = 0; j < row.length + 2; j++) {
                    var td = document.createElement("td");
                    // modify for cell 0
                    if ( j == 0 ) {
                        var btn = document.createElement('input');
                        btn.type = 'button';
                        btn.id = startIndexForRead + i;
                        btn.value= "modify" ;
                        // modify function
                        btn.onclick = function(e) { 
                            var updateRow = e.target.id;
                            // index in table    
                            var ti = Number(updateRow) - Number(CurrentPageVisitor) * Number(RowsInPageVisitor);
                            ti += 1;
                            setCookie( 'updateRow', updateRow );
                            document.getElementById("modify-account").value = visitorTable.rows[ti].cells[2].innerHTML;
                            document.getElementById("modify-password").value = visitorTable.rows[ti].cells[3].innerHTML;

                            modifyScreen();
                        }
                        td.appendChild(btn);
                    }
                    // no for cell 3
                    else if ( j == 1 )  {
                        var txt = document.createTextNode( startIndexForRead + i + 1 );
                        td.appendChild(txt);
                    }
                    else {
                        // id check
                        if ( j == 2 ) {
                            continue;
                        }
                        else {
                            var txt = document.createTextNode(row[j-2]);
                            td.appendChild(txt);
                        }
                    }
                    tr.appendChild(td);
                }            
                // append row to table
                // IE7 requires append row to tbody, append tbody to table
                tbody.appendChild(tr);
                visitorTable.appendChild(tbody);
            }
        }
    })
}

function modifyAccount() {
    // update ok ?
    var updateRow = getCookie( 'updateRow');
    var account = document.getElementById("modify-account").value;
    var password = document.getElementById("modify-password").value;   
    var letterNumber = /^(\d|[a-zA-Z]){4,16}$/;
    if ( account.length == 0  ) {
        alert( "account is empty" );
    }                     
    else if ( password.length == 0  ) {
        alert( "password is empty" );
    }             
    else if (!password.match( letterNumber )) {
        alert( "The password is 4-16 digits or letters" );
    }
    else {    
        // update row
        $.get("/php/adminvisitor.php",{ updateRow : updateRow, account : account,
            password : password   } ,function(data) {
            if ( data == 1 ) 
                alert("update failure");
            else {
                // show table
                deletevisitorTableRows();
                addVisitorTable();
            } 
        });
    }
    normalScreen();
}

function normalScreen() {
/*
    visitorTable.style.display = 'block';
    var addAccountBar = document.getElementById("page-move-bar");
    addAccountBar.style.display = 'block';;

    var addAccountBar = document.getElementById("modify-account-bar");
    addAccountBar.style.display = 'none';;
*/
    window.location.reload();
}

function modifyScreen() {
    visitorTable.style.display = 'none';
    var addAccountBar = document.getElementById("page-move-bar");
    addAccountBar.style.display = 'none';;

    var addAccountBar = document.getElementById("modify-account-bar");
    addAccountBar.style.display = 'block';;
}

// delete all rows in owner table
function deletevisitorTableRows() {
    var visitorTable = document.getElementById("visitorTable");
    while(visitorTable.rows.length > 1) {
        visitorTable.deleteRow(1);
    }
}

function getRows() {
    // get row count
    allRowsVisitor = getCookie( 'allRowsVisitor' );
    document.getElementById("ownerRowsShow").innerHTML = allRowsVisitor + " entries";
}

function removePageMoveList() {
    // Get the <ul> element with id="myList"
    var list = document.getElementById("pageMoveList");

    // As long as <ul> has a child node, remove it
    while (list.hasChildNodes()) {   
        list.removeChild(list.firstChild);
    }
}

function setPageMoveList() {

    // read pos information
    allRowsVisitor = getCookie( 'allRowsVisitor' );

    RowsInPageVisitor = getCookie( 'RowsInPageVisitor' );
    ShowPagesInPageMoveListVisitor = getCookie( 'ShowPagesInPageMoveListVisitor' );
    CurrentPageVisitor = getCookie( 'CurrentPageVisitor' );
    FirstPageInPageMoveListVisitor = getCookie( 'FirstPageInPageMoveListVisitor' );

    // get the all pages
    var allPages = Math.floor( allRowsVisitor / RowsInPageVisitor );
    var addPage = allRowsVisitor - ( allPages * RowsInPageVisitor );
    if ( addPage != 0  ) {
        allPages += 1;
    }

    var ul = document.getElementById("pageMoveList");
    // all page < ShowPagesInPageMoveListVisitor
    if ( allPages <= ShowPagesInPageMoveListVisitor ) {
        for( var idxPage = 0; idxPage < allPages; idxPage++ ) {
            var li = document.createElement("li");
            var a = document.createElement("a");
            var content = Number(FirstPageInPageMoveListVisitor) + Number(1) + Number(idxPage);
            a.textContent = content;
            a.setAttribute('href', "#");
            a.setAttribute("id", content);
            li.appendChild(a);
            li.setAttribute("id", content);
            ul.appendChild(li);
        }
    }
    else {
        if ( FirstPageInPageMoveListVisitor != 0 ) {
            // <<
            var li = document.createElement("li");
            var a = document.createElement("a");
            var content = '<<';
            a.textContent = content;
            a.setAttribute('href', "#");
            a.setAttribute("id", content);
            li.appendChild(a);    
            ul.appendChild(li);
        }
        for( var idxPage = 0; idxPage < ShowPagesInPageMoveListVisitor; idxPage++ ) {
            var li = document.createElement("li");
            var a = document.createElement("a");
            var content = Number(FirstPageInPageMoveListVisitor) + Number(1) + Number(idxPage);
            a.textContent = content;
            a.setAttribute('href', "#");
            a.setAttribute("id", content);
            li.appendChild(a);
            ul.appendChild(li);
        }
        if ( Number(FirstPageInPageMoveListVisitor) + Number(ShowPagesInPageMoveListVisitor) < 
            Number(allPages) ) {
            // >>
            var li = document.createElement("li");
            var a = document.createElement("a");
            var content = '>>';
            a.textContent = content;
            a.setAttribute('href', "#");
            a.setAttribute("id", content);
            li.appendChild(a);    
            ul.appendChild(li);
        }
    }
    ul.addEventListener('click', function(e) {
        // read pos information
        allRowsVisitor = getCookie( 'allRowsVisitor' );
        RowsInPageVisitor = getCookie( 'RowsInPageVisitor' );
        ShowPagesInPageMoveListVisitor = getCookie( 'ShowPagesInPageMoveListVisitor' );
        FirstPageInPageMoveListVisitor = getCookie( 'FirstPageInPageMoveListVisitor' );
        // page move
        // get the all pages
        var allPages = Math.floor( allRowsVisitor / RowsInPageVisitor );
        var addPage = allRowsVisitor - ( allPages * RowsInPageVisitor );
        if ( addPage != 0  ) {
            allPages += 1;
        }
        var amountPageMove = Math.round( ShowPagesInPageMoveListVisitor / 2 );
        // preview
        if( e.target.id == '<<' ) {
            FirstPageInPageMoveListVisitor -= amountPageMove;
            if ( FirstPageInPageMoveListVisitor < 0 )  {
                FirstPageInPageMoveListVisitor = 0;
            }
            // set first page in page move list 
            setCookie( 'FirstPageInPageMoveListVisitor', FirstPageInPageMoveListVisitor );

            // remove page move list
            removePageMoveList();
            setPageMoveList();
        }
        // after
        else if( e.target.id == '>>' ) {
            FirstPageInPageMoveListVisitor = Number(FirstPageInPageMoveListVisitor) +  Number(amountPageMove);
            var endPage =  Number(FirstPageInPageMoveListVisitor) +  Number(ShowPagesInPageMoveListVisitor);
            if ( endPage > allPages ) {
                FirstPageInPageMoveListVisitor = Number(allPages) - Number(ShowPagesInPageMoveList);
            }
            // set first page in page move list 
            setCookie( 'FirstPageInPageMoveListVisitor', FirstPageInPageMoveListVisitor );

            // remove page move list
            removePageMoveList();
            setPageMoveList();
        }
        // page number
        else {
            CurrentPageVisitor = getCookie( 'CurrentPageVisitor' );
            var movePage =   Number( e.target.id ) - 1;
            // same page ?
            if ( CurrentPageVisitor != movePage ) {
                setCookie( 'CurrentPageVisitor', movePage);
                deletevisitorTableRows();
                addvisitorTable();
            }
        }
    });
}

function getCookie(c_name) {
    return localStorage.getItem(c_name);
}

function setCookie(c_name, value) {
    return localStorage.setItem(c_name, value);
}
function gotoFirstPage() {
    if (confirm("Do you really want to signup?")) {
        if( getCookie( 'admin_rememberMeCheck' ) != "yes" ) {
            // cookie setting
            setCookie( "admin_account", "");
            setCookie( "admin_password", "");
        }
        window.location.href="/admin.html";  
    }
}
