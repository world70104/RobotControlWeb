/////////////////////////////////////////////////////////////////////////
//
//                          owner.js 
//
//    owner login
//
//  Date: 2018/09/25
//  Version: 1.0
//
//  Make by M.H team
//
//////////////////////////////////////////////////////////////////////////

function rememberCheck() {
    // Get the checkbox
    var checkBox = document.getElementById("rememberMe");
    var owner_rememberMeCheck = '';
    if (checkBox.checked == true){
        setCookie('owner_rememberMeCheck', 'yes');
    } else {
        setCookie('owner_rememberMeCheck', 'no');
    }
}

function onLogin() {
    // get the parameter
    account = document.getElementById("account").value;
    password = document.getElementById("password").value;
    var result = "";
    // check parameter
    if ( account.length == 0 ) {
        document.getElementById("error_text").innerHTML = "Please the account";
    } 
    else {
        if ( password.length == 0 ) {
            document.getElementById("error_text").innerHTML = "Please the password";
        }  
        else {
            var login = "login";
            $.get("/php/owner.php",{ login:login, account:account, password:password } 
                ,function(data) {
                if ( data == "0" ) {
                        result = "No database.";
                        document.getElementById("error_text").innerHTML = result;
                }
                else if ( data == "3" ) {
                        result = "mistake account or password.";
                        document.getElementById("error_text").innerHTML = result;
                }
                else if ( data == "4" ) {
                    result = "No robots.";
                    document.getElementById("error_text").innerHTML = result;
                }
                else if ( data == "5" ) {
                    result = "The robot is not online.";
                    document.getElementById("error_text").innerHTML = result;
                }
                else if ( data == "6" ) {
                    result = "The robot is occupied.";
                    document.getElementById("error_text").innerHTML = result;
                }
                else if(
                    ( data == "7" ) ||
                    ( data == "9" ) ) {
                    result = "The robot is private mode,please enter temporary password.";
                    document.getElementById("error_text").innerHTML = result;
                }
                else if ( data == "8" ) {
                        result = "The account is using.";
                        document.getElementById("error_text").innerHTML = result;
                }
                else {
                    result = "";
                    document.getElementById("error_text").innerHTML = result;
                    // owner
                    if ( data == "1" ) {
                        // owner login successful ?
                        alert( "owner log in susccessful" ); 
                        // cookie setting
                        setCookie( "owner_account", account);
                        setCookie( "owner_password", password);
                        window.location.href="/html/ownerstream.html";  
                    }
                }
            });
        }          
    }
}

function getCookie(c_name) {
    return localStorage.getItem(c_name);
}

function setCookie(c_name, value) {
    return localStorage.setItem(c_name, value);
}

function onRegister() {
    setCookie('user_kind', 'owner');
    window.location.href="/html/register.html";
}