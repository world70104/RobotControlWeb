/////////////////////////////////////////////////////////////////////////
//
//                          user.js 
//
//    login
//
//  Date: 2018/09/25
//  Version: 1.0
//
//  Make by M.H team
//
//////////////////////////////////////////////////////////////////////////

function rememberCheck() {
    // Get the checkbox
    var checkBox = document.getElementById("rememberMe");
    var user_rememberMeCheck = '';
    if (checkBox.checked == true){
        setCookie('user_rememberMeCheck', 'yes');
    } else {
        setCookie('user_rememberMeCheck', 'no');
    }
}

function onLogin() {
    // get the parameter
    account = document.getElementById("account").value;
    password = document.getElementById("password").value;
    var tempPassword = password.toUpperCase();
    var result = "";
    // check parameter
    if ( account.length == 0 ) {
        document.getElementById("error_text").innerHTML = "Please the account";
    } 
    else {
        if ( password.length == 0 ) {
            document.getElementById("error_text").innerHTML = "Please the password";
        }  
        else {
            // get the robot name
            var useToRobot = getCookie('useToRobot');
            //                        setCookie('useToRobot', useToRobot);
            var login = "login";
            // call index.php
            $.get("/php/user.php",{ login:login, account:account, password:password, 
                tempPassword:tempPassword, useToRobot:useToRobot } ,function(data) {
                if ( data == "0" ) {
                        result = "No database.";
                        document.getElementById("error_text").innerHTML = result;
                }
                else if ( data == "3" ) {
                        result = "mistake account or password.";
                        document.getElementById("error_text").innerHTML = result;
                }
                else if ( data == "4" ) {
                    result = "No robots.";
                    document.getElementById("error_text").innerHTML = result;
                }
                else if ( data == "5" ) {
                    result = "The robot is not online.";
                    document.getElementById("error_text").innerHTML = result;
                }
                else if ( data == "6" ) {
                    result = "The robot is occupied.";
                    document.getElementById("error_text").innerHTML = result;
                }
                else if(
                    ( data == "7" ) ||
                    ( data == "9" ) ) {
                    result = "The robot is private mode,please enter temporary password.";
                    document.getElementById("error_text").innerHTML = result;
                }
                else if ( data == "8" ) {
                        result = "The account is using.";
                        document.getElementById("error_text").innerHTML = result;
                }
                else {
                    result = "";
                    document.getElementById("error_text").innerHTML = result;
                    // visitor
                    if( data == "2" ) {
                        // visitor login successful ?
                        alert( "visitor log in susccessful" ); 
                        // cookie setting
                        setCookie( "user_account", account);
                        setCookie( "user_password", password);
//                        setCookie('useToRobot', useToRobot);

                        window.location.href="/html/visitorstream.html";  
                    }
                }
            });
        }          
    }
}

function getCookie(c_name) {
    return localStorage.getItem(c_name);
}

function setCookie(c_name, value) {
    return localStorage.setItem(c_name, value);
}

function onRegister() {
    setCookie('user_kind', 'visitor');
    window.location.href="/html/register.html";
}